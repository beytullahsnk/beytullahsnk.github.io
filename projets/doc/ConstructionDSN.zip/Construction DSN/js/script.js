
function sendMail() {
    let allAreFilled = true;
    document.getElementById("form").querySelectorAll("[required]").forEach(function(i) {
      if (!i.value) { allAreFilled = false;   }
    })
    if (allAreFilled){
        var params = {
        name : document.getElementById("name").value,
        email : document.getElementById("email").value,
        num : document.getElementById("num").value,
        message : document.getElementById("message").value
    }

    emailjs.send("service_yu27k43","template_q34ehgb",params)
    .then(function(response) {
        swal("Envoyé !", "Votre message a été envoyé avec succès!", "success")
        document.getElementById("name").value=""
        document.getElementById("email").value=""
        document.getElementById("num").value=""
        document.getElementById("message").value="";
     }, function(error) {
        swal("Erreur !", "Votre message n'a pas été envoyé !", "error");
    })
    }
    if (!allAreFilled) {
      swal('Veuillez remplir les champs obligatoires !');
    }
  };


const menu = document.querySelector(".menu");
const navMenu = document.querySelector(".nav-menu");
const navLink = document.querySelectorAll(".nav-link");

menu.addEventListener("click", mobileMenu);
navLink.forEach(n => n.addEventListener("click", closeMenu));

function mobileMenu() {
    menu.classList.toggle("active");
    navMenu.classList.toggle("active");
}

function closeMenu() {
    menu.classList.remove("active");
    navMenu.classList.remove("active");
}
