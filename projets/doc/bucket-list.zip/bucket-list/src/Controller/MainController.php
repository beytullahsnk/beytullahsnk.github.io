<?php

namespace App\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class MainController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function home()
    {
        return $this->render("home.html.twig");
    }

    /**
     * @Route("/base", name="test")
     */
    public function base()
    {
        return $this->render("base.html.twig");
    }

    /**
     * @Route("/about", name="aboutus")
     */
    public function about()
    {
        return $this->render("about.html.twig");
    }
}