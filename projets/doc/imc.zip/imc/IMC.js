// déclaration des variables
var nom="";
var prenom="";
var mail="";
var confirmation_mail="";
var annee="";
var mois="";
var jour="";
var taille="";
var taille2="";
var poids="";
var agee="";
var imc="";

// déclaration des variables pour vérification
var nomVerif="";
var prenomVerif="";
var mailVerif="";
var confirmation_mailVerif="";
var anneeVerif="";
var moisVerif="";
var jourVerif="";
var tailleVerif="";
var poidsVerif="";

// input NOM
function FunctionNom(){
    
    var checkLetter = /^[a-zA-Z- ]+$/;

    var erreur=document.getElementById("erreurNom");  

    nom = document.getElementById("nom").value;

    if (!nom.match(checkLetter)){
        erreur.innerHTML="Votre nom doit posseder uniquement des lettres";
        erreur.style.color = "red";
        nomVerif=false;
    }

    if (nom.length < 3){
        erreur.innerHTML="Votre nom doit comporter au moins 3 caractères";
        erreur.style.color = "red";
        nomVerif=false;
    }
    
    if (nom.match(checkLetter) && nom.length >= 3){
        erreur.innerHTML="";
        nomVerif=true;
    }
    Verif();
}

// input PRENOM
function FunctionPrenom(){
    
    var checkLetter = /^[a-zA-Z- ]+$/;

    var erreur=document.getElementById("erreurPrenom");  

    prenom = document.getElementById("prenom").value;

    if (!prenom.match(checkLetter)){
        erreur.innerHTML="Votre prenom doit posseder uniquement des lettres";
        erreur.style.color = "red";
        prenomVerif=false;
    }

    if (prenom.length < 2){
        erreur.innerHTML="Votre prénom doit comporter au moins 2 caractères";
        erreur.style.color = "red";
        prenomVerif=false;
    }
    
    if (prenom.match(checkLetter) && prenom.length >= 2){
        erreur.innerHTML="";
        prenomVerif=true;
    }
    Verif();
}

// input MAIL
function FunctionMail(){

    var checkMail= /^([a-zA-Z0-9_-]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;

    var erreur = document.getElementById("erreurMail");  

    mail = document.getElementById("mail").value;

    if (!mail.match(checkMail)){
        erreur.innerHTML="Votre mail est incorrect";
        erreur.style.color = "red";
        mailVerif=false;
    }
    else {
        erreur.innerHTML="";
        mailVerif=true;
    }
    Verif();
}

// input VERIF MAIL
function FunctionMailverif(){

    var mail = document.getElementById("mail").value;

    var erreur = document.getElementById("erreurMailverif");

    confirmation_mail = document.getElementById("confirmation_mail").value;

    if (mail != confirmation_mail){
        erreur.innerHTML="Les mails insérés ne sont pas identique";
        erreur.style.color = "red";
        confirmation_mailVerif=false;
    }
    else {
        erreur.innerHTML="";
        confirmation_mailVerif=true;
    }
    Verif();
}

// input ANNEE
function FunctionAnnee(){
    
    var checkNumber = /^[0-9]+$/;

    annee = document.getElementById("annee").value;

    var erreur = document.getElementById("erreurAnnee");

    if (!annee.match(checkNumber) || annee.length != 4){
        erreur.innerHTML="L'année doit être au format aaaa avec des chiffres uniquement (ex: 1980)";
        erreur.style.color = "red";
        anneeVerif=false;
    }
    
    else if (annee>new Date().getFullYear()){
        erreur.innerHTML="L'année doit être égal ou inférieur à "+new Date().getFullYear();
        erreur.style.color = "red";
        anneeVerif=false;
    }
    else {
        erreur.innerHTML="";
        anneeVerif=true;
    }
    Verif();
}

// input MOIS
function FunctionMois(){

    var checkNumber = /^[0-9]+$/;

    var erreur = document.getElementById("erreurMois");

    mois = document.getElementById("mois").value;

    if (!(mois > 0 && mois < 13)){
        erreur.innerHTML="Il n'y as que 12 mois !";
        erreur.style.color = "red";
        moisVerif=false;
    }

    if (!mois.match(checkNumber)){
        erreur.innerHTML="Insérer uniquement des chiffres";
        erreur.style.color = "red";
        moisVerif=false;
    }

    else if (mois.length != 2){
        erreur.innerHTML="Le format doit être MM (ex: 06)";
        erreur.style.color = "red";
        moisVerif=false;
    }

    if (mois.match(checkNumber) && (mois > 0 && mois < 13) && mois.length == 2){
        erreur.innerHTML="";
        moisVerif=true;
    }
    Verif();
}    

// input JOUR
function FunctionJour(){

    var checkNumber = /^[0-9]+$/;

    var erreur = document.getElementById("erreurJour");

    jour = document.getElementById("jour").value;

    if (!(jour > 0 && jour < 32)){
        erreur.innerHTML="Jour invalide";
        erreur.style.color = "red";
        jourVerif=false;
    }

    if (!jour.match(checkNumber)){
        erreur.innerHTML="Insérer uniquement des chiffres";
        erreur.style.color = "red";
        jourVerif=false;
    }
    else if (jour.length != 2){
        erreur.innerHTML="Le format doit être JJ (ex: 08)";
        erreur.style.color = "red";
        jourVerif=false;
    }

    if (jour.match(checkNumber) && (jour > 0 && jour < 32) && jour.length == 2){
        erreur.innerHTML="";
        jourVerif=true;
    }
    Verif();
}

// input TAILLE
function FunctionTaille(){

    var checkNumber = /^[0-9](.*?)+$/;

    taille = document.getElementById("taille").value;

    var erreur = document.getElementById("erreurTaille");

    if (!taille.match(checkNumber)){
        erreur.innerHTML="Le format n'est pas correct ! Insérer uniquement des chiffres (ex:1.82)";
        erreur.style.color = "red";
        tailleVerif=false;
    }    
    else if (taille>2.7){
        erreur.innerHTML="La taille ne doit pas être supérieur à 2.7 mètre";
        erreur.style.color = "red";
        tailleVerif=false;
    }
    else{
        erreur.innerHTML="";
        tailleVerif=true;
    }
    Verif();
}

// input POIDS
function FunctionPoids(){

    var checkNumber = /^[0-9]+$/;

    poids = document.getElementById("poids").value;

    var erreur = document.getElementById("erreurPoids");

    if (!poids.match(checkNumber)){
        erreur.innerHTML="Le format n'est pas correct ! Insérer uniquement des chiffres (ex:82)";
        erreur.style.color = "red";
        poidsVerif=false;
    }    
    else if (poids>650){
        erreur.innerHTML="Le poids ne doit pas être supérieur à 650 kg";
        erreur.style.color = "red";
        poidsVerif=false;
    }
    else{
        erreur.innerHTML="";
        poidsVerif=true;
    }
    Verif();
}


// fonction pour calculer l'age
function getAge(date) { 
    var diff = Date.now() - date.getTime();
    var age = new Date(diff); 
    return Math.abs(age.getUTCFullYear() - 1970);
}

//fonction pour calculer l'IMC
function calcul_Imc(poids,taille){
    taille =  taille*taille;
    return poids/taille;
}
imc = calcul_Imc(poids,taille);

//Affiche la représentation de l'IMC
function repreImc(imc){
    if (imc < 16.5){
        return "Famine"
    }
    if (imc < 18.5){
        return "Maigreur"
    }
    if (imc < 25){
        return "Corpulance normale"
    }
    if (imc < 30){
        return "Surpoids"
    }
    if (imc < 35){
        return "Obésité modérée"
    }
    if (imc < 40){
        return "Obésité sévère"
    }
    if (imc > 40){
        return "Obésité morbide ou massive"
    }
}

// Afficher informations de l'utilisateur et afficher son IMC
function FunctionCalculer(){
    var nomAff = document.getElementById("nomAff");
    var prenomAff = document.getElementById("prenomAff");
    var mailAff = document.getElementById("mailAff");
    var date_de_naiss = document.getElementById("date_de_naiss");
    var tailleAff = document.getElementById("tailleAff");
    var poidsAff = document.getElementById("poidsAff");
    var imcAff = document.getElementById("imcAff");


    nomAff.innerHTML="Nom : "+nom;
    prenomAff.innerHTML="Prénom : "+prenom;
    mailAff.innerHTML="Mail : "+mail;
    date_de_naiss.innerHTML="Date de naissance : "+jour+"/"+mois+"/"+annee;
    tailleAff.innerHTML="Taille : "+taille +" m";
    poidsAff.innerHTML="Poids : "+poids +" kg";

    agee = (getAge(new Date(annee, mois, jour)));

    taille2 = taille*taille;
    imc = poids/taille2;

    if (agee < 18){
        imcAff.innerHTML="IMC non disponible pour les mineurs !";
    }
    else{
        imcAff.innerHTML="Votre IMC est de " +imc+ " donc cela represente "+repreImc(imc);
    }
}

// Verification pour activer le boutton soumettre
function Verif(){
    if(nomVerif==true && prenomVerif==true && mailVerif==true && confirmation_mailVerif==true && anneeVerif==true && moisVerif==true && jourVerif==true && tailleVerif==true && poidsVerif==true){
        document.getElementById("boutton"). disabled = false;
    }
    else{
        document.getElementById("boutton"). disabled = true;
    }
}
Verif();